/*
 * 排序器接口
 */

package dsa;

public interface Sorter {
	public void sort(Sequence s);
}