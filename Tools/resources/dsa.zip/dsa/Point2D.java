/*
 * 平面整格点
 */

package dsa;

public class Point2D {
	private int x, y;
	
	public Point2D(int xx, int yy)
	{	x = xx;	y = yy; }

	public int getX()
	{	return x; }

	public int getY()
	{	return y; }
}